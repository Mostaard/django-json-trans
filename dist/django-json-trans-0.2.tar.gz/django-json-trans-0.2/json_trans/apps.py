from django.apps import AppConfig


class TranslationsConfig(AppConfig):
    name = 'clt.apps.translations'
